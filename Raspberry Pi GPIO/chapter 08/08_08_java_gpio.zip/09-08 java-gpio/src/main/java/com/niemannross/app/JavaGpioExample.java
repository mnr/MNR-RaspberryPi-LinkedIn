
/*
 * Based on BlinkTriggerGpioExample.java from pi4j
 * 
 * Following is original documentation
 * 
 * #%L
 * **********************************************************************
 * ORGANIZATION  :  Pi4J
 * PROJECT       :  Pi4J :: Java Examples
 * FILENAME      :  BlinkTriggerGpioExample.java
 *
 * This file is part of the Pi4J project. More information about
 * this project can be found here:  http://www.pi4j.com/
 * **********************************************************************
 * %%
 * Copyright (C) 2012 - 2019 Pi4J
 * %%
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Lesser Public License for more details.
 *
 * You should have received a copy of the GNU General Lesser Public
 * License along with this program.  If not, see
 * <http://www.gnu.org/licenses/lgpl-3.0.html>.
 * #L%
 */
import java.util.concurrent.Callable;

import com.pi4j.io.gpio.GpioController;
import com.pi4j.io.gpio.GpioFactory;
import com.pi4j.io.gpio.GpioPinDigitalInput;
import com.pi4j.io.gpio.GpioPinDigitalOutput;
import com.pi4j.io.gpio.PinPullResistance;
import com.pi4j.io.gpio.PinState;
import com.pi4j.io.gpio.RaspiPin;
import com.pi4j.io.gpio.trigger.GpioBlinkStateTrigger;
import com.pi4j.io.gpio.trigger.GpioBlinkStopStateTrigger;
import com.pi4j.io.gpio.trigger.GpioCallbackTrigger;

/**
 * This example code demonstrates how to setup blinking triggers for GPIO pins on the Raspberry Pi.
 * MNR: addition of binary counter
 * MNR: change to myButton so that it resets counter
 *
 * @authors Robert Savage, Mark Niemann-Ross
 */
public class JavaGpioExample {
        
        // setup gpio output pins and make sure they are all LOW at startup
        static GpioPinDigitalOutput led1;
        static GpioPinDigitalOutput led2;
        static GpioPinDigitalOutput led4;
        static GpioPinDigitalOutput led8;
        
        static int lightCounter;

    public static void main(String[] args) throws InterruptedException {

        System.out.println("<--Pi4J--> GPIO Blink Trigger Example ... started.");

        // create gpio controller
        final GpioController gpio = GpioFactory.getInstance();

        // provision gpio pin #09 as an input pin with its internal pull up resistor enabled
        final GpioPinDigitalInput resetButton = gpio.provisionDigitalInputPin(RaspiPin.GPIO_09,
                                                  PinPullResistance.PULL_UP);

        // setup gpio output pins and make sure they are all LOW at startup
        led1 = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_29, PinState.LOW);
        led2 = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_28, PinState.LOW);
        led4 = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_27, PinState.LOW);
        led8 = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_25, PinState.LOW);
        
        resetButton.addTrigger(new GpioCallbackTrigger(new Callable<Void>() {
                public Void call() {
                        while(resetButton.isLow()) {
                                System.out.println("button pressed");
                                turnLightsOn(15);
                                lightCounter = 0;
                        } 
                        turnLightsOn(0);
 
                        return null; 
                        }
                } ));

        // keep program running until user aborts (CTRL-C)
        while(true) {
                lightCounter = 0;
                while (lightCounter < 16 ) {
                        turnLightsOn(lightCounter);
                        Thread.sleep(1000);
                        lightCounter++;
                }

        }

        // stop all GPIO activity/threads by shutting down the GPIO controller
        // (this method will forcefully shutdown all GPIO monitoring threads and scheduled tasks)
        // gpio.shutdown();   <--- implement this method call if you wish to terminate the Pi4J GPIO controller
    }
    
    public static void turnLightsOn(int lightMask) {
        // 0 <= lightMask < 16 ... the number to represent in binary
        System.out.println("turnLightsOn: " + lightMask);

        led1.setState( (lightMask & 1) > 0 );
        led2.setState( (lightMask & 2) > 0 );
        led4.setState( (lightMask & 4) > 0 );
        led8.setState( (lightMask & 8) > 0 );
    }
}
